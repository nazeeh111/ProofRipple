# ProofRipple portable implication case

Python 3.10+: `python3 read_case.py` checks recorded integrity and prints outcomes. This is not proof or authentication. Core Lean 4.33.1 and the separately installed ProofRipple 0.3.2.dev0 are required for fresh checks: `proofripple verify-run selected --recheck`. Reproduce with `proofripple discover invariants.json --method graph --select 1 --budget 8 --out fresh-run`. Every output must be new. The seed format in Seed.lean can also be used as discover input. No runtime is bundled.

All nodes are arbitrary Props; primitive arrows are explicit hypotheses. The starting registry includes the checked seed p4→p6. One selected p4→p11 consequence yields 1/4→4/4 at eight dequeued-proposition search expansions; without selection stays1/4; the longer no_gain chain stays0/4. Five-expansion edited case changes0/4→4/4. A bounded failure is not a counterexample, novelty claim or general prover comparison. Inspect exact types/axioms in run.json and generated ProofRipple.lean. The frozen Mathlib study is separate and does not establish learned advantage.

Recorded from current main f63eae7899c8bf34e4819cb41a7fa60ebcab169c on2026-11-17. New material/source MIT, LICENSE included; external Lean Apache-2.0. SHA256SUMS identifies bytes without authenticating the sender.
